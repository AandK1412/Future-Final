---
title: Chapter 5 Captured
---

# Chapter 5: Captured

Authorities arrest Yeonmi and her mother.

**Outcome:**  
They are imprisoned or sent to labor camps. The journey ends here.
