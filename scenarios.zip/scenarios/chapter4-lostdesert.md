---
title: Chapter 4 Lost in the Desert
---

# Chapter 4: Lost in the Desert

Without a guide, Yeonmi and her mother run out of water.

**Outcome:**  
They collapse in the desert. The journey ends here.
