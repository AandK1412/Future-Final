---
title: Chapter 2 China
---

# Chapter 2: Surviving in China

In China, Yeonmi and her mother face new dangers. A missionary offers help, but traffickers also approach.

### What would you do?
- [Trust the missionary]({{ site.baseurl }}/story/chapter3-desert)
- [Pay the traffickers]({{ site.baseurl }}/story/chapter3-scam)
