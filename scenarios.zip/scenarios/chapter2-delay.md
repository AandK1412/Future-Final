---
title: Chapter 2 Delay
---

# Chapter 2: Delay and Danger

They wait another night, but patrols increase.

### What would you do?
- [Attempt crossing tomorrow]({{ site.baseurl }}/story/chapter3-caught)
- [Find another escape route]({{ site.baseurl }}/story/chapter3-broker)
