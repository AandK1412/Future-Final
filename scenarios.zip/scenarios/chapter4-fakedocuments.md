---
title: Chapter 4 Fake Documents
---

# Chapter 4: Fake Documents

Yeonmi hands over fake documents at the airport.

### What would you do?
- [Try to board the plane]({{ site.baseurl }}/story/chapter5-mongolia)
- [Documents fail]({{ site.baseurl }}/story/chapter5-captured)
