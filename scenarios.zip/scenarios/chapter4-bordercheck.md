---
title: Chapter 4 Border Check
---

# Chapter 4: Border Check

At the Mongolian border, a guard stops them.

### What would you do?
- [NGO bribes the guard]({{ site.baseurl }}/story/chapter5-mongolia)
- [The guard betrays you]({{ site.baseurl }}/story/chapter5-captured)
