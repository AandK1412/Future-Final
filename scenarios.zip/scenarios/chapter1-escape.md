---
title: Chapter 1 Escape
---

# Chapter 1: Escape from North Korea

Yeonmi and her mother stand at the Yalu River. It’s dark, freezing, and guards patrol nearby.

### What would you do?
- [Cross the river tonight]({{ site.baseurl }}/story/chapter2-china)
- [Wait another night]({{ site.baseurl }}/story/chapter2-delay)
