---
title: Chapter 3 Desert Crossing
---

# Chapter 3: Crossing the Gobi Desert

The missionary arranges a desert guide. Supplies are limited.

### What would you do?
- [Use NGO guide]({{ site.baseurl }}/story/chapter4-bordercheck)
- [Go alone]({{ site.baseurl }}/story/chapter4-lostdesert)
