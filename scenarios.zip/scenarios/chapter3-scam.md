---
title: Chapter 3 Scam
---

# Chapter 3: Traffickers’ Scam

The traffickers take the money but abandon Yeonmi and her mother.

**Outcome:**  
They are caught and sold into trafficking. The journey ends here.
