---
title: Chapter 5 Mongolia Escape
---

# Chapter 5: Escape to Mongolia

With the help of the NGO or fake documents, Yeonmi makes it to Ulaanbaatar.

### What would you do?
- [Fly to South Korea]({{ site.baseurl }}/story/chapter6-southkorea)
