---
title: Chapter 6 South Korea
---

# Chapter 6: Arrival in South Korea

Yeonmi arrives safely in Seoul.

### What would you do next?
- Become an activist, sharing your story.
- Rebuild a quiet family life.

**Congratulations — you completed the journey successfully!**
