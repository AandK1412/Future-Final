---
title: Chapter 3 Chinese Broker
---

# Chapter 3: Chinese Broker

A broker offers fake documents — at a high price.

### What would you do?
- [Use the documents]({{ site.baseurl }}/story/chapter4-fakedocuments)
