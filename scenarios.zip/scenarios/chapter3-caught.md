---
title: Chapter 3 Caught at River
---

# Chapter 3: Caught at the River

Guards catch them crossing. They are deported back to North Korea.

**Outcome:**  
The journey ends in failure.
